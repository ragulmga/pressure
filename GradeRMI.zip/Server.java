import java.rmi.*;  
import java.rmi.registry.*;  
import java.rmi.registry.LocateRegistry;
public class Server{
    public static void main(String[] args) throws Exception{
        System.setProperty("java.rmi.server.hostname", "localhost");
        Addi obj = new Add();   
        Naming.rebind("rmi://localhost:5000/jithan", obj);
    }
}
