import java.rmi.*;
import java.rmi.server.*;
public class Add extends UnicastRemoteObject implements Addi {
    private static final long serialVersionUID = 1L;
    public Add() throws Exception{
        super();
    }
    public String add(int x, int y,int z, int p,int q){

    	String grade="";
    	int total = (x+y+z+p+q)/5;
    	if(total>90 && total<=100){
    		grade+="S";
    	}
    	else if(total>80 && total<=90){
        	grade+="A";
    	}
        
        else if(total>70 && total<=80){
        	grade+="B";
        }
        
        else if(total>60 && total<=70){
        	grade+="C";
        }else{
        	grade+="E";
        }

        return grade;
}
}