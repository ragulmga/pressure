package d2r;

public class d2rclass implements d2rinterface{
	public float dollar_2_rupee(float dollar) {
		
		float rupee=dollar*70;
		return rupee;
		
	}
	public float rupee_2_dollar(float rupee) {
		float dollar=rupee/70;
		return dollar;
		
	}
	
}
