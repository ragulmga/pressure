package d2r;

public interface d2rinterface {
	public float dollar_2_rupee(float dollar);
	public float rupee_2_dollar(float rupee);

}
