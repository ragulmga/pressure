import java.rmi.*;
import java.util.Scanner;

public class RMIClient{
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num;
        try{
            long start = System.currentTimeMillis();
            Fibonacci fibo = (Fibonacci) Naming.lookup("rmi://localhost:5000/eniyan");
            num=sc.nextInt();
            System.out.println(fibo.fibonacci(num));
            long end = System.currentTimeMillis();
            System.out.println("Time taken in ms: "+ (end-start));
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
}