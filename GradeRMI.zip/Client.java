import java.util.*;
import java.util.concurrent.TimeUnit;
import java.rmi.*;
public class Client {
    public static void main(String[] args) throws Exception{
        long beforeUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
        long startTime=System.nanoTime();
        TimeUnit.SECONDS.sleep(5);
        int a,b,c,d,e;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the marks: ");
        a=sc.nextInt();
        b=sc.nextInt();
        c=sc.nextInt();
        d=sc.nextInt();
        e=sc.nextInt();

        Addi obj=(Addi)Naming.lookup("rmi://localhost:5000/jithan");
        System.out.print("Grade : ");
        System.out.println(obj.add(a,b,c,d,e));
        long endTime=System.nanoTime();
        long elapsedTime=endTime-startTime;
        System.out.println("Time: "+elapsedTime);
        long afterUsedMem=Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
        long actualMemUsed=afterUsedMem-beforeUsedMem;
        System.out.println("Memory usage:"+actualMemUsed);
    }
}
