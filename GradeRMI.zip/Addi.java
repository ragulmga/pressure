import java.rmi.*;
public interface Addi extends Remote{
    public String add(int a, int b, int c, int d,int e) throws Exception;
}
