# CloudSim Task Allocation and Scheduling

* Particle Swarm Optimization `PSO.PSO_Scheduler`
* Round Robin Algorithm       `RoundRobin.RoundRobinScheduler`
* Shortest Job First          `SJF.SJF_Scheduler`
* First Come First Serve      `FCFS.FCFS_Scheduler`
